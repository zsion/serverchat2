<?php

$servername  = 'localhost';
$dbname      = '';
$dbusername  = '';
$dbpassword  = '';

define('WELIVE', true);
define('TABLE_PREFIX', 'kefu_');
define('COOKIE_KEY', 'p3kaeaKOwFB3');
define('WEBSITE_KEY', '9v832vduU44p');
define('BASEPATH', dirname(dirname(__FILE__)).'/');

?>