<?php

$_CFG = array();

$_CFG['cActived'] = "1";
$_CFG['cUpdate'] = "6";
$_CFG['cAutoOffline'] = "6";
$_CFG['cLang'] = "Auto";
$_CFG['cTimezone'] = "+8";
$_CFG['cDateFormat'] = "Y年n月j日";
$_CFG['cTitle'] = "588返还网在线客服系统";
$_CFG['cTitle_en'] = "588返还网 Online Support";
$_CFG['cWelcome'] = "欢迎您登录588返还网客服系统, 请咨询, 谢谢!";
$_CFG['cWelcome_en'] = "Welcome! please post your question...";
$_CFG['cAppVersion'] = '授权版本';
$_CFG['cAppName'] = "V2VMaXZl";
$_CFG['cAppCopyrighURL'] = "aHR0cDovL3d3dy53ZWVudGVjaC5jb20v";
$_CFG['cKillRobotCode'] = '598a6a77ffeba710c59020b60abce95d';
$_CFG['cDeleteHistory'] = "240";
$_CFG['cBannedips'] = "";
$_CFG['cBadwords'] = "";
$_CFG['cPanalHeight'] = "200";

?>