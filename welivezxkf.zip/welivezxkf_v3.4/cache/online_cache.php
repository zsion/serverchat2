<?php
if(!defined('WELIVE')) die('File not found!');

$welive_onlines  = array (
  2 => 
  array (
    'groupname' => '销售咨询',
    'groupename' => 'Sales Service',
    'description' => '',
    'descriptionen' => '',
    'user' => 
    array (
      7 => 
      array (
        'username' => '旺得天下',
        'type' => '1',
        'isonline' => '0',
        'isbusy' => '0',
        'userfrontname' => '旺得天下',
        'userfrontename' => 'wangwang',
      ),
      8 => 
      array (
        'username' => '阿勇',
        'type' => '1',
        'isonline' => '0',
        'isbusy' => '0',
        'userfrontname' => '阿勇',
        'userfrontename' => 'ayong',
      ),
    ),
  ),
);

?>